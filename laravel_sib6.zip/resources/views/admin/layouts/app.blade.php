@include('admin.layouts.header')
@include('admin.layouts.sidebar')
<div class="container-fluid px-4">

@yield('konten')

</div>

@include('admin.layouts.footer')