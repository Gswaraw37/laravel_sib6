<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Test</title>
</head>
<body>
    <h1>Hello Ini file pertama saya didalam view laravel</h1>
    <?php
        $nama = 'Budi';
        $nilai = 59.00;    
    ?>

    
    <?php if($nilai >= 60): ?>
        <?php 
            $ket = "Lulus";
        ?>
    <?php else: ?>
        <?php
            $ket = "Tidak Lulus";
        ?>
    <?php endif; ?>

    
    <?php echo e($nama); ?> <p> Dengan Nilai </p> <?php echo e($nilai); ?> <p> Dinyatakan </p> <?php echo e($ket); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_sib6\resources\views/hello.blade.php ENDPATH**/ ?>