
<?php $__env->startSection('content'); ?>

<section class="py-5">
    <div class="container px-4 px-lg-5 my-5">
        <div class="row gx-4 gx-lg-5 align-items-center">
            <div class="col-md-6">
                <?php if(empty($produk->foto)): ?> 
                    <img class="card-img-top mb-5 mb-md-0" src="<?php echo e(url('admin/img/nophoto.jpg')); ?>" alt="..." />
                <?php else: ?>
                    <img class="card-img-top mb-5 mb-md-0" src="<?php echo e(url('admin/img')); ?>/<?php echo e($produk->foto); ?>" alt="..." />
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="small mb-1"><?php echo e($produk->jenis_produk->nama); ?></div>
                <h1 class="display-5 fw-bolder"><?php echo e($produk->nama); ?></h1>
                <div class="fs-5 mb-5">
                    <span class="text-decoration-line-through">$45.00</span>
                    <span>Rp<?php echo e(number_format($produk->harga_jual,0,',','.')); ?></span>
                </div>
                <p class="lead"><?php echo e($produk->deskripsi); ?></p>
                <?php if(auth()->guard()->check()): ?>
                    <div class="d-flex">
                        <button class="btn btn-outline-dark flex-shrink-0" type="button">
                            <a class="btn btn-outline-dark mt-auto" href="<?php echo e(route('add.to.cart', $produk->id)); ?>">
                                <i class="bi-cart-fill me-1"></i>
                                    Add To Cart
                            </a>
                        </button>
                    </div>
                <?php else: ?>
                    <a class="btn btn-outline-dark mt-auto" href="<?php echo e(route('login')); ?>">Add To Cart?</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_sib6\resources\views/front/detail.blade.php ENDPATH**/ ?>