<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Ini adalah file kedua</h1>

    <?php
        $no = 1;
        $s1 = ['nama' => 'Fawazz', 'nilai' => 70];    
        $s2 = ['nama' => 'Ali', 'nilai' => 80];    
        $s3 = ['nama' => 'Andi', 'nilai' => 80];    
        $s4 = ['nama' => 'Aji', 'nilai' => 60];    
        $s5 = ['nama' => 'Adi', 'nilai' => 90];
        $judul = ['No', 'Nama', 'Nilai', 'Keterangan'];
        
        $siswa = [$s1, $s2, $s3, $s4, $s5];
    ?>
    <table align="center" border="1" cellpadding="10">
        <thead>
            <tr>
                
                <?php $__currentLoopData = $judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($jdl); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $ket = ($s['nilai'] >= 60) ? 'Lulus' : 'Gagal';
                    $warna = ($no % 2 == 1) ? 'Green' : 'Yellow';
                ?>
                <tr bgcolor="<?php echo e($warna); ?>">
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($s['nama']); ?></td>
                    <td><?php echo e($s['nilai']); ?></td>
                    <td><?php echo e($ket); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel_sib6\resources\views/nilai/daftar_nilai.blade.php ENDPATH**/ ?>