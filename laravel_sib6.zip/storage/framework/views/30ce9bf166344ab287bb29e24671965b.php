
<?php $__env->startSection('konten'); ?>
<?php if(Auth::user()->role != 'staff' && Auth::user()->role != 'manager'): ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Kartu</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Kartu</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <a href="" class="btn btn-md btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-square-plus"></i></a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Diskon</th>
                        <th>Iuran</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Diskon</th>
                        <th>Iuran</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $kartu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($k->kode); ?></td>
                            <td><?php echo e($k->nama); ?></td>
                            <td><?php echo e($k->diskon); ?></td>
                            <td><?php echo e($k->iuran); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Kartu</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="/admin/kartu/store" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <input type="text" class="form-control" name="kode" id="kode" aria-describedby="emailHelp" placeholder="Tambahkan Kode">
            </div>
            <div class="mb-3">
                <input type="text" class="form-control" name="nama" id="nama" aria-describedby="emailHelp" placeholder="Tambahkan Nama">
            </div>
            <div class="mb-3">
                <input type="text" class="form-control" name="diskon" id="diskon" aria-describedby="emailHelp" placeholder="Tambahkan Diskon">
            </div>
            <div class="mb-3">
                <input type="text" class="form-control" name="iuran" id="iuran" aria-describedby="emailHelp" placeholder="Tambahkan Iuran">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Tambah</button>
            </div>
        </form>
      </div>
    </div>
  </div>
<?php else: ?>
<?php
    abort(403, 'Forbidden');
?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_sib6\resources\views/admin/kartu/index.blade.php ENDPATH**/ ?>